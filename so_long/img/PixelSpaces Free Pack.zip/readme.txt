Hi! Thank you for downloading Pixel Spaces! As stated in the project page, this
is a Free version containing a smaller portion of the entire pack, intended for 
experimentation or small projects. 

If you would like to purchase the pack but cannot afford to, let me know by sending 
me a DM on Twitter and we can discuss a different price suitable for both of us  :)

If you have any requests or questions, please leave a comment at the project page or DM/@ me on twitter!

License:
- This asset pack can be used in any non-commercial project, you may modify the assets as you wish. 
- This asset pack cannot be used in any commercial project, resold/redistributed, or used in any way to directly or indirectly gain revenue, even if modified - this includes as NFTs. 
- This asset pack cannot be used  as basis for AI-generated content.

Credit is not required but very much appreciated! Let me know of any projects you have finished :) 

Project Page: https://netherzapdos.itch.io/pixel-spaces
Twitter: https://twitter.com/Netherzapdoss